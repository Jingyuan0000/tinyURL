import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  templateUrl: './404.component.html',
})
export class NotFoundComponent {
    // TODO: 404 page not loadings
}
