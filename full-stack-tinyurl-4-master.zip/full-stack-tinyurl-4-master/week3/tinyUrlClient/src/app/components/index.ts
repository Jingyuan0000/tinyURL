export * from './home.component';
export * from './about.component';
export * from './url.component';
export * from './404.component';
